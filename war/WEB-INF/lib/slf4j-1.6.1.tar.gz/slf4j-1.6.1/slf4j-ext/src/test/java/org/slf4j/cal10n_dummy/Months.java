package org.slf4j.cal10n_dummy;

import ch.qos.cal10n.BaseName;

@BaseName("months")
public enum Months {

  JAN, FEB, MAR, APR, MAY, JUN;

}
